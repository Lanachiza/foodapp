const { MongoClient } = require('mongodb');

const uri = "mongodb+srv://ignaciovillasenorb:Fatality1212@myapp.iy8e1e6.mongodb.net/?retryWrites=true&w=majority&appName=Myapp";

async function run() {
  const client = new MongoClient(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  try {
    await client.connect();
    console.log("Conexión establecida con MongoDB");

    const database = client.db("FoodTiesaDelivery");
    const carritoCollection = database.collection("carrito");

    const carrito = await carritoCollection.find({}).toArray();
    console.log("Elementos del carrito:", carrito);


  } finally {

    await client.close();
    console.log("Conexión cerrada con MongoDB");
  }
}

run().catch(console.error);